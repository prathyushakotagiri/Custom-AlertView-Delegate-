//
//  CustomAlertView.h
//  HumStar
//
//  Created by Amar on 23/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

enum 
{
    CustomAlertViewButtonTagOk = 1000,
    CustomAlertViewButtonTagCancel,
    CustomAlertViewButtonTagYes,
};

@class CustomAlertView;

@protocol CustomAlertViewDelegate

@required
- (void) CustomAlertView:(CustomAlertView *)alert wasDismissedWithValue:(int)buttonTag;

@optional
- (void) customAlertViewWasCancelled:(CustomAlertView *)alert;

@end

@interface CustomAlertView : UIViewController <UITextFieldDelegate>
{
    UIView      *alertView;
    UIView      *backgroundView;
   
    NSString    *strMessage;
    NSString    *strSubMessage;
    
    NSString *strOkButtonTitle;
    NSString *strCancelButtonTitle;
    NSString *strYesButtonTitle;
    
    //id<NSObject, CustomAlertViewDelegate> delegate;
}

@property (nonatomic, assign) IBOutlet id<CustomAlertViewDelegate, NSObject> delegate;

@property (strong, nonatomic) IBOutlet UIImageView *imgHeader;
@property (strong, nonatomic) IBOutlet UIImageView *imgBorder;

@property (retain, nonatomic) NSString *strMessage;
@property (retain, nonatomic) NSString *strSubMessage;

@property (retain, nonatomic) IBOutlet UILabel *lblHeader;
@property (retain, nonatomic) IBOutlet UILabel *lblSubMessage;

@property (retain, nonatomic) IBOutlet UIButton *buttonYes;
@property (retain, nonatomic) IBOutlet UIButton *buttonNo;
@property (nonatomic, retain) IBOutlet UIButton *buttonOK;

@property (nonatomic, retain) IBOutlet  UIView *alertView;
@property (nonatomic, retain) IBOutlet  UIView *backgroundView;


-(void)setYesButtonTitle:(NSString *)title;
-(void)setNoButtonTitle:(NSString *)title;
-(void)setOkButtonTitle:(NSString *)title;

- (IBAction)showOk;
- (IBAction)showYesNo;
- (IBAction)dismiss:(id)sender;

- (void)alertDidFadeOut;

@end

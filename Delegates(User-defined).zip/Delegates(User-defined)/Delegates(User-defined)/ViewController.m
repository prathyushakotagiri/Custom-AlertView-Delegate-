//
//  ViewController.m
//  Delegates(User-defined)
//
//  Created by Prathyusha kotagiri on 9/28/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize alert;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

#pragma mark - Show Alert
- (IBAction)showAlert:(id)sender {
    
    UIButton *btn = sender;
    
    alert = [[CustomAlertView alloc]init];
    alert.strMessage =@"Custom alert";
    alert.strSubMessage = @"Alert sub-message will be shown. Automatically subviews on the custom alert will be adjusted, eventhough the submessage is too long.";
    alert.delegate = self;

    if (btn.tag == 1) {
        [alert showOk];
    }else{
        [alert setYesButtonTitle:@"Submit"];
        [alert setNoButtonTitle:@"Dismiss"];
        [alert showYesNo];
    }
    
}

#pragma mark - CustomAlertView Delegate Method
-(void)CustomAlertView:(CustomAlertView *)alert wasDismissedWithValue:(int)buttonTag
{
    if( buttonTag == CustomAlertViewButtonTagYes ){
        NSLog(@"Yes button clicked");
    }else if ( buttonTag == CustomAlertViewButtonTagOk ){
        NSLog(@"Ok button clicked");
    }else if ( buttonTag == CustomAlertViewButtonTagCancel ){
        NSLog(@"Cancel button clicked");
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

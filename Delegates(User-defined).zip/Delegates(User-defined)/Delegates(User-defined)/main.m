//
//  main.m
//  Delegates(User-defined)
//
//  Created by Prathyusha kotagiri on 9/28/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

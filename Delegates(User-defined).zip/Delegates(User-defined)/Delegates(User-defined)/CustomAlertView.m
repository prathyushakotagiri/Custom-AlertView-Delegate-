//
//  CustomAlertView.m
//  HumStar
//
//  Created by Amar on 23/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CustomAlertView.h"
#import <QuartzCore/QuartzCore.h>

@interface CustomAlertView()
- (void)alertDidFadeOut;
@end

@implementation CustomAlertView
@synthesize alertView;
@synthesize backgroundView;
@synthesize delegate;
@synthesize buttonOK;
@synthesize lblHeader;
@synthesize lblSubMessage;
@synthesize buttonYes;
@synthesize buttonNo;
@synthesize strMessage;
@synthesize strSubMessage;

#pragma mark -
#pragma mark IBActions

// Show with only OK button
- (IBAction)showOk
{
    // Retaining self is odd, but we do it to make this "fire and forget"
    [self retain];
    
    // We need to add it to the window, which we can get from the delegate
    id appDelegate = [[UIApplication sharedApplication] delegate];
    UIWindow *window = [appDelegate window];
    
    // Make sure the alert covers the whole window
    self.view.frame = window.frame;
    self.view.center = window.center;
   
    float fxCenterPosition =  self.view.center.x - backgroundView.center.x;
    float fyCenterPosition =  self.view.center.y - backgroundView.center.y;
    
    
    CGRect frameHeader = self.lblHeader.frame;
    self.lblHeader.frame = CGRectMake(frameHeader.origin.x+fxCenterPosition,frameHeader.origin.y+fyCenterPosition, frameHeader.size.width, frameHeader.size.height);
    [self.lblHeader setText:strMessage];
    
    CGRect frameHeaderImage = self.imgHeader.frame;
    self.imgHeader.frame = CGRectMake(frameHeaderImage.origin.x+fxCenterPosition,frameHeaderImage.origin.y+fyCenterPosition, frameHeaderImage.size.width, frameHeaderImage.size.height);
    
    CGRect frameBorder = self.imgBorder.frame;
    self.imgBorder.frame = CGRectMake(frameBorder.origin.x+fxCenterPosition,frameBorder.origin.y+fyCenterPosition, frameBorder.size.width, frameBorder.size.height);
    
    
    CGRect lblOrgframe = lblSubMessage.frame;
    [self.lblSubMessage setText:strSubMessage];
    
    CGRect lblsizeToFit = [self.lblSubMessage.text boundingRectWithSize:CGSizeMake(lblSubMessage.frame.size.width, 200) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont fontWithName:@"Helvetica" size:14]} context:nil];
    lblSubMessage.frame = CGRectMake(lblSubMessage.frame.origin.x + fxCenterPosition, lblSubMessage.frame.origin.y+fyCenterPosition, lblSubMessage.frame.size.width, lblsizeToFit.size.height);
    [lblSubMessage sizeToFit];
    
    CGFloat diff = (lblSubMessage.frame.size.height-lblOrgframe.size.height);
    
    CGRect frameYes = self.buttonOK.frame;
    buttonOK.frame = CGRectMake(frameYes.origin.x+fxCenterPosition,frameYes.origin.y+diff+8+fyCenterPosition, frameYes.size.width, frameYes.size.height);
    
    CGRect frame = backgroundView.frame;
    backgroundView.frame = CGRectMake(frame.origin.x+fxCenterPosition,frame.origin.y+fyCenterPosition, frame.size.width, frame.size.height+diff+8);

    if(strOkButtonTitle)
        [self.buttonOK setTitle:strOkButtonTitle forState:UIControlStateNormal];
    
    self.buttonYes.hidden = TRUE;
    self.buttonNo.hidden = TRUE;

    self.buttonOK.hidden = FALSE;
    self.buttonOK.enabled = TRUE;
    
    [window addSubview:self.view];
}

// Show with yes and No Buttons
- (IBAction)showYesNo
{
    // Retaining self is odd, but we do it to make this "fire and forget"
    [self retain];
    
    // We need to add it to the window, which we can get from the delegate
    id appDelegate = [[UIApplication sharedApplication] delegate];
    UIWindow *window = [appDelegate window];
    
    // Make sure the alert covers the whole window
    self.view.frame = window.frame;
    self.view.center = window.center;
    
    float fxCenterPosition =  self.view.center.x - backgroundView.center.x;
    float fyCenterPosition =  self.view.center.y - backgroundView.center.y;

    
    CGRect frameHeader = self.lblHeader.frame;
    self.lblHeader.frame = CGRectMake(frameHeader.origin.x+fxCenterPosition,frameHeader.origin.y+fyCenterPosition, frameHeader.size.width, frameHeader.size.height);
    [self.lblHeader setText:strMessage];

    CGRect frameHeaderImage = self.imgHeader.frame;
    self.imgHeader.frame = CGRectMake(frameHeaderImage.origin.x+fxCenterPosition,frameHeaderImage.origin.y+fyCenterPosition, frameHeaderImage.size.width, frameHeaderImage.size.height);
    
    CGRect frameBorder = self.imgBorder.frame;
    self.imgBorder.frame = CGRectMake(frameBorder.origin.x+fxCenterPosition,frameBorder.origin.y+fyCenterPosition, frameBorder.size.width, frameBorder.size.height);


    CGRect lblOrgframe = lblSubMessage.frame;
    [self.lblSubMessage setText:strSubMessage];
    
    CGRect lblsizeToFit = [self.lblSubMessage.text boundingRectWithSize:CGSizeMake(lblSubMessage.frame.size.width, 200) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont fontWithName:@"Helvetica" size:14]} context:nil];
    lblSubMessage.frame = CGRectMake(lblSubMessage.frame.origin.x + fxCenterPosition, lblSubMessage.frame.origin.y+fyCenterPosition, lblSubMessage.frame.size.width, lblsizeToFit.size.height);
    [lblSubMessage sizeToFit];
    
    CGFloat diff = (lblSubMessage.frame.size.height-lblOrgframe.size.height);
    
    CGRect frameYes = self.buttonYes.frame;
    buttonYes.frame = CGRectMake(frameYes.origin.x+fxCenterPosition,frameYes.origin.y+diff+8+fyCenterPosition, frameYes.size.width, frameYes.size.height);
    
    CGRect frameNo = self.buttonNo.frame;
    buttonNo.frame = CGRectMake(frameNo.origin.x+fxCenterPosition,frameNo.origin.y+diff+8+fyCenterPosition, frameNo.size.width, frameYes.size.height);
    
    CGRect frame = backgroundView.frame;
    backgroundView.frame = CGRectMake(frame.origin.x+fxCenterPosition,frame.origin.y+fyCenterPosition, frame.size.width, frame.size.height+diff+8);
    
    if(strYesButtonTitle)
        [self.buttonYes setTitle:strYesButtonTitle forState:UIControlStateNormal];
    
    if(strCancelButtonTitle)
        [self.buttonNo setTitle:strCancelButtonTitle forState:UIControlStateNormal];
    
    self.buttonOK.hidden = TRUE;
    
    self.buttonYes.hidden = FALSE;
    self.buttonNo.hidden = FALSE;
    
    self.buttonYes.enabled = TRUE;
    self.buttonNo.enabled = TRUE;
    
    [window addSubview:self.view];
}

-(void)setYesButtonTitle:(NSString *)title
{
    strYesButtonTitle = [NSString stringWithString:title];
}

-(void)setNoButtonTitle:(NSString *)title
{
    strCancelButtonTitle = [NSString stringWithString:title];
}

-(void)setOkButtonTitle:(NSString *)title
{
    strOkButtonTitle = [NSString stringWithString:title];
}

- (IBAction)dismiss:(id)sender
{
    [UIView beginAnimations:nil context:nil];
    self.view.alpha = 0.0;
    [UIView commitAnimations];
    
    [self performSelector:@selector(alertDidFadeOut) withObject:nil afterDelay:0.5];
    
    if (sender == self || [sender tag] == CustomAlertViewButtonTagYes || [sender tag] == CustomAlertViewButtonTagOk || [sender tag] == CustomAlertViewButtonTagCancel)
    {
        [delegate CustomAlertView:self wasDismissedWithValue:(int)[sender tag]];
    }
    else
    {
        if ([delegate respondsToSelector:@selector(customAlertViewWasCancelled:)])
            [delegate customAlertViewWasCancelled:self];
    } 
}

#pragma mark -
- (void)viewDidUnload 
{
    [self setLblHeader:nil];
    [self setLblSubMessage:nil];
    [self setButtonYes:nil];
    [self setButtonNo:nil];
    self.alertView = nil;
    self.backgroundView = nil;
    [super viewDidUnload];

}
- (void)dealloc 
{
    [alertView release];
    [backgroundView release];
    [lblHeader release];
    [lblSubMessage release];
    [buttonYes release];
    [buttonNo release];
    [buttonOK release];
    [strMessage release];
    [strSubMessage release];
    [super dealloc];
}

#pragma mark -
#pragma mark Private Methods
- (void)alertDidFadeOut
{    
    [self.view removeFromSuperview];
    [self autorelease];
}

@end
